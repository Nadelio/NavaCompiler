# Nava Language Support Extension

### Set up:
In order to use this extension, you will have to install it manually
1. Open the extensions tab
2. Press the 3 dots at the top of the tab
3. Click the button "Install from .vsix"
4. Navigate to the "nava-language-support-1.0.5.vsix" file and select it
5. VSCode should do the rest, but you will need to restart VSCode or reload VSCode for the extension to start working.
6. Enjoy syntax highlighting!
